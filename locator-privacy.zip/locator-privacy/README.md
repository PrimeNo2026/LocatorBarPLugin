# LocatorPrivacy – Installations- und Testanleitung

## 1. Voraussetzungen

- **Java 21** (mindestens) auf deinem Entwicklungsrechner installiert, zum Kompilieren.
  `java -version` prüfen. Falls älter: https://adoptium.net/ (Temurin 21 oder neuer).
- **Maven** installiert (`mvn -version`). Falls nicht vorhanden: https://maven.apache.org/download.cgi
  oder, einfacher, eine IDE wie IntelliJ IDEA (Community Edition, kostenlos), die Maven
  bereits mitbringt.
- Ein **PacketEvents**-Plugin-JAR (Spigot/Paper-Variante), separat heruntergeladen von
  https://modrinth.com/plugin/packetevents oder https://www.spigotmc.org/resources/packetevents.80279/
  Lade die aktuellste Version, die explizit 1.21.6 oder neuer unterstützt.

> Warum zwei JARs? LocatorPrivacy nutzt PacketEvents nur als **Werkzeug**, bindet es aber
> nicht in die eigene JAR ein (keine Shading). Das hält unsere JAR klein und
> aktuell, weil PacketEvents regelmäßig eigene Updates für neue Minecraft-Versionen
> veröffentlicht, unabhängig von unserem Plugin.

## 2. Kompilieren

Im Projektordner (dort, wo `pom.xml` liegt):

```bash
mvn clean package
```

Die fertige Datei liegt danach unter:

```
target/locator-privacy-1.0.0.jar
```

**Hinweis:** In dieser Entwicklungsumgebung hier habe ich keinen Internetzugriff, konnte
also nicht selbst `mvn package` ausführen und die Downloads der Paper-API / PacketEvents
verifizieren. Führe den Befehl bei dir lokal aus – falls Fehler auftauchen, schick mir
die Fehlermeldung, dann beheben wir das gemeinsam.

## 2b. Alternative: Automatisch bauen lassen mit GitHub Actions (ZIP muss NICHT entpackt werden)

Du musst die ZIP hierfür **nicht** auf deinem Rechner entpacken. Du lädst sie als
Ganzes hoch, und GitHub entpackt und baut sie für dich. Genaue Anleitung dazu
steht in der separaten Nachricht/Datei "GitHub-Anleitung" – kurz zusammengefasst:

1. Neues, leeres GitHub-Repository erstellen.
2. Die Datei `locator-privacy.zip` unverändert (ohne Entpacken!) über
   **Add file → Upload files** hochladen und committen.
3. Eine neue Datei `.github/workflows/release.yml` über **Add file → Create new
   file** anlegen (Pfad inkl. Slashes einfach in das Namensfeld eintippen) und
   den Workflow-Inhalt hineinkopieren.
4. Über **Releases → Draft a new release** einen Tag (z.B. `v1.0.0`)
   veröffentlichen → GitHub entpackt die ZIP automatisch und baut die JAR.
5. Nach ein bis zwei Minuten liegt die fertige JAR unter **Releases**.

## 3. Upload auf deinen exaroton-Server

1. exaroton-Webpanel öffnen → deinen Server auswählen.
2. Tab **Dateien** öffnen, in den Ordner `plugins/` wechseln.
3. Beide Dateien hochladen:
   - `locator-privacy-1.0.0.jar` (dein kompiliertes Plugin)
   - die PacketEvents-JAR (z.B. `packetevents-spigot-2.9.5.jar`)
4. Server über das Panel **neu starten** (nicht nur "Stop/Start" durch Crash – sauber
   über den Neustart-Button, damit `plugin.yml` korrekt eingelesen wird).
5. In der Server-Konsole prüfen, ob beim Start erscheint:
   ```
   [LocatorPrivacy] LocatorPrivacy wurde aktiviert. Hide-Modus: OFF
   ```
   Falls stattdessen ein Fehler zu `packetevents` erscheint: PacketEvents ist nicht
   korrekt geladen – prüfe, ob die JAR wirklich im `plugins/`-Ordner liegt und zur
   Serverversion passt.

## 4. Testen

- `/locator` als normaler Spieler → GUI sollte sich öffnen mit drei Optionen.
- Zwei Testaccounts/-fenster öffnen: Spieler A stellt "Niemand" ein → Spieler B sollte
  A nicht mehr auf der Locator Bar (F3 bzw. das Minimap-/Locator-HUD) sehen.
- Spieler A stellt "Ausgewählte Spieler" ein, fügt B über das Untermenü hinzu →
  B sieht A, ein dritter Spieler C sieht A nicht. **Das ist der entscheidende Test**
  für die individuelle Sichtbarkeit.
- Als Admin (mit `locatorprivacy.admin.hide`, standardmäßig OP): `/hide status`,
  `/hide off`, `/hide on` ausprobieren.
- Im OFF-Modus: Spieler stellt "Niemand" ein → nach 10 Minuten automatisch wieder
  sichtbar, danach 10 Minuten lang nicht erneut vollständig versteckbar
  (`/locator` → "Niemand" klicken → Fehlermeldung mit Restzeit).

## 5. Troubleshooting – falls die individuelle Sichtbarkeit nicht greift

Das Waypoint-Paket-Format ist eine sehr junge Minecraft-Funktion (seit 1.21.6), und
PacketEvents kann die zugehörigen Wrapper-Klassen zwischen Versionen leicht anders
benennen. Falls die Locator Bar bei dir **gar nicht** reagiert (also auch "Alle"/
"Niemand" keinen Unterschied machen):

1. Prüfe die Server-Konsole nach dem Login zweier Testspieler auf Einträge wie
   `Konnte Waypoint-Paket nicht lesen` (Log-Level FINE, ggf. `logging.level` in
   `config.yml` deines Servers hochdrehen, oder temporär `Level.FINE` in
   `WaypointVisibilityListener.java` auf `Level.WARNING` ändern, neu kompilieren).
2. Öffne die Javadoc deiner exakten PacketEvents-Version
   (`https://javadocs.packetevents.com/`, Version in der URL anpassen) und schau dir
   `WrapperPlayServerWaypoint` sowie die Klasse an, die `getWaypoint()` zurückgibt
   (z.B. `TrackedWaypoint`). Prüfe, wie dort die Spieler-UUID tatsächlich heißt.
3. Schick mir die exakten Methodennamen, die du dort findest – ich passe dir
   `extractPlayerUuid()` in `WaypointVisibilityListener.java` dann gezielt an.

Das ist bewusst so gebaut (mit mehreren Kandidaten-Methodennamen statt einer fest
verdrahteten Signatur), damit das Plugin auch nach kleineren PacketEvents-Updates
mit hoher Wahrscheinlichkeit weiterläuft – aber bei einer so neuen API kann ich dir
ohne Zugriff auf die exakte, bei dir installierte Version nicht zu 100 % garantieren,
dass die Methodennamen beim ersten Versuch treffen.

## 6. Wichtige Designentscheidungen (zum Nachvollziehen)

- **Warum PacketEvents und nicht nur `waypoint_transmit_range`?** Die vanilla-Attribute
  sind rein symmetrisch (ich bin für alle sichtbar oder für niemanden). "A sieht B,
  C nicht" ist damit technisch nicht abbildbar – nur über das Abfangen einzelner
  Pakete pro Empfänger.
- **Zeitstempel statt Restzeiten:** Hide-Fenster und Abklingzeit werden als absolute
  Zeitpunkte (`System.currentTimeMillis()`) in `hidestate.yml` gespeichert. Das macht
  Neustarts und Relogging wirkungslos als Umgehungsversuch.
- **Abklingzeit-Sichtbarkeit:** Während der erzwungenen Mindestsichtbarkeit ist ein
  Spieler für **alle** sichtbar (nicht nur für einen einzelnen, fest gewählten
  Betrachter). Das erfüllt zuverlässig die Anforderung "mindestens ein anderer
  Spieler muss ihn sehen können", auch wenn einzelne Spieler offline gehen.

## 7. Projektstruktur

```
locator-privacy/
├── pom.xml
├── README.md
└── src/main/
    ├── resources/
    │   ├── plugin.yml
    │   └── config.yml
    └── java/de/locatorprivacy/
        ├── LocatorPrivacyPlugin.java
        ├── settings/      (persönliche Sichtbarkeitseinstellungen, YAML-Persistenz)
        ├── hide/           (Admin ON/OFF-Modus, Zeitfenster, Abklingzeit)
        ├── gui/            (Inventar-GUIs für /locator)
        ├── waypoints/      (Paket-Filterung = Kern der individuellen Sichtbarkeit)
        ├── commands/       (/locator, /hide)
        └── util/           (deutsche Nachrichten)
```
