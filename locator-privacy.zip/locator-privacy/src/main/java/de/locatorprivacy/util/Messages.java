package de.locatorprivacy.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

/**
 * Zentrale Sammlung aller deutschen Spieler-Nachrichten.
 */
public final class Messages {

    private Messages() {
    }

    public static final Component PREFIX = Component.text("[LocatorPrivacy] ", NamedTextColor.GRAY);

    public static Component info(String text) {
        return PREFIX.append(Component.text(text, NamedTextColor.AQUA));
    }

    public static Component success(String text) {
        return PREFIX.append(Component.text(text, NamedTextColor.GREEN));
    }

    public static Component error(String text) {
        return PREFIX.append(Component.text(text, NamedTextColor.RED));
    }

    public static Component warn(String text) {
        return PREFIX.append(Component.text(text, NamedTextColor.YELLOW));
    }

    public static final Component NO_PERMISSION = error("Dafür hast du keine Berechtigung.");
    public static final Component ONLY_PLAYERS = error("Dieser Befehl kann nur von Spielern ausgeführt werden.");
    public static final Component UNKNOWN_SUBCOMMAND = error("Unbekannter Unterbefehl. Nutze /hide on, /hide off, /hide status oder /hide debug.");
    public static final Component PLAYER_NOT_FOUND = error("Dieser Spieler wurde nicht gefunden.");

    public static Component hideModeSet(String mode) {
        return success("Server-Hide-Modus wurde auf " + mode + " gesetzt.");
    }

    public static Component hideStatus(String mode) {
        return info("Aktueller Server-Hide-Modus: " + mode);
    }

    public static Component cannotHideYet(long remainingSeconds) {
        long minutes = remainingSeconds / 60;
        long seconds = remainingSeconds % 60;
        return error(String.format(
                "Du kannst dich gerade nicht vollständig verstecken, da du dich noch in der Abklingzeit befindest (%d Min %d Sek verbleibend).",
                minutes, seconds));
    }

    public static Component visibilitySet(String mode) {
        return success("Deine Locator-Bar-Sichtbarkeit wurde auf \"" + mode + "\" gesetzt.");
    }

    public static Component viewerAdded(String name) {
        return success(name + " wurde zu deiner Liste hinzugefügt.");
    }

    public static Component viewerRemoved(String name) {
        return success(name + " wurde von deiner Liste entfernt.");
    }
}
