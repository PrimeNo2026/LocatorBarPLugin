package de.locatorprivacy.waypoints;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWaypoint;
import de.locatorprivacy.hide.HideStateManager;
import de.locatorprivacy.settings.PlayerVisibilitySettings;
import de.locatorprivacy.settings.SettingsManager;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Das eigentliche Herzstück des Plugins.
 *
 * Die vanilla Locator-Bar-Attribute (waypoint_transmit_range /
 * waypoint_receive_range) sind symmetrisch: sie legen nur fest, OB ein
 * Spieler überhaupt als Waypoint gesendet wird, nicht FÜR WEN. Eine
 * individuelle "A sieht B, C aber nicht"-Steuerung ist damit nicht
 * möglich (siehe Machbarkeitsanalyse).
 *
 * Deshalb wird hier jedes ausgehende Waypoint-Paket (PacketType.Play.
 * Server.WAYPOINT, seit 1.21.6) pro Empfänger einzeln abgefangen und bei
 * Bedarf unterdrückt, bevor es den Client erreicht. Dadurch bekommt jeder
 * Spieler nur die Waypoints der Spieler, die ihn laut deren persönlicher
 * Einstellung (oder laut Hide-Zwangssichtbarkeit) sehen lassen.
 *
 * WICHTIGER HINWEIS ZUR WARTUNG:
 * Das Waypoint-System ist eine noch recht junge Minecraft-Funktion
 * (seit 1.21.6) und die PacketEvents-Wrapper-Klassen dafür können sich
 * zwischen PacketEvents-Versionen in Details unterscheiden. Die Methode
 * extractPlayerUuid() versucht deshalb mehrere gängige Methodennamen
 * reflektiv, statt sich auf eine einzige, exakte Signatur zu verlassen.
 * Falls dein Server nach dem Deployment KEINE Paket-Filterung zeigt,
 * prüfe zuerst mit /locatorprivacy debug (siehe README) oder den
 * Server-Log, ob extractPlayerUuid() eine UUID findet, und passe bei
 * Bedarf die Kandidaten-Methodennamen unten an die exakte Javadoc-Version
 * deiner installierten PacketEvents-JAR an.
 */
public class WaypointVisibilityListener extends PacketListenerAbstract {

    private static final String[] IDENTIFIER_ACCESSOR_NAMES = {"getIdentifier", "identifier", "getSource", "source"};
    private static final String[] UUID_ACCESSOR_NAMES = {"getUuid", "uuid", "getId", "id", "getPlayerId", "playerId"};
    // Laut offiziellem Minecraft-Quellcode steckt die Spieler-UUID nicht
    // direkt in einer Methode, sondern in einem "Either<UUID, String>"
    // (entweder eine Spieler-UUID, oder ein benannter Welt-Wegpunkt).
    // Diese Kandidaten-Namen decken gängige Either-Implementierungen ab
    // (DataFixerUpper-Stil: left()/right() geben meist Optional<T> zurück;
    // manche Varianten werfen stattdessen, wenn die falsche Seite abgefragt wird).
    private static final String[] EITHER_LEFT_ACCESSOR_NAMES = {"left", "getLeft", "leftOrThrow", "orThrow", "unwrap"};

    private final JavaPlugin plugin;
    private final SettingsManager settingsManager;
    private final HideStateManager hideStateManager;

    // Laufzeit-umschaltbar über /hide debug, siehe HideCommand.
    private volatile boolean debug = false;
    // Verhindert, dass der einmalige Reflection-Dump (siehe logClassInfoOnce)
    // bei jedem Paket erneut läuft.
    private volatile boolean dumpedClassInfoThisSession = false;

    public WaypointVisibilityListener(JavaPlugin plugin, SettingsManager settingsManager, HideStateManager hideStateManager) {
        super(PacketListenerPriority.NORMAL);
        this.plugin = plugin;
        this.settingsManager = settingsManager;
        this.hideStateManager = hideStateManager;
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
        if (debug) {
            // Beim Einschalten erneut dumpen, auch wenn schon mal gelaufen -
            // praktisch, wenn man /hide debug mehrfach während des Testens nutzt.
            dumpedClassInfoThisSession = false;
        }
    }

    public boolean isDebug() {
        return debug;
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        if (event.getPacketType() != PacketType.Play.Server.WAYPOINT) {
            return;
        }
        if (!(event.getPlayer() instanceof Player viewer)) {
            return;
        }

        WrapperPlayServerWaypoint wrapper;
        Object waypointObject;
        UUID targetUuid;
        try {
            wrapper = new WrapperPlayServerWaypoint(event);
            waypointObject = wrapper.getWaypoint();
            if (debug) {
                logClassInfoOnce(waypointObject);
            }
            targetUuid = extractPlayerUuid(waypointObject);
        } catch (Exception ex) {
            plugin.getLogger().log(debug ? Level.WARNING : Level.FINE,
                    "[Debug] Konnte Waypoint-Paket nicht lesen, lasse es unverändert durch.", ex);
            return;
        }

        if (debug) {
            plugin.getLogger().info("[Debug] WAYPOINT-Paket an " + viewer.getName()
                    + " | Waypoint-Klasse=" + (waypointObject == null ? "null" : waypointObject.getClass().getName())
                    + " | extrahierte Spieler-UUID=" + targetUuid);
        }

        if (targetUuid == null) {
            // Kein spielerbezogenes Waypoint (z.B. ein Welt-Wegpunkt), ODER
            // die Extraktion ist fehlgeschlagen -> nicht unterscheidbar,
            // deshalb sicherheitshalber unverändert durchlassen.
            return;
        }
        if (targetUuid.equals(viewer.getUniqueId())) {
            if (debug) {
                plugin.getLogger().info("[Debug] -> ist der Spieler selbst, immer sichtbar.");
            }
            return;
        }

        boolean visible = canSee(viewer.getUniqueId(), targetUuid);
        if (debug) {
            plugin.getLogger().info("[Debug] -> sichtbar für " + viewer.getName() + "? " + visible
                    + (visible ? "" : " -> Paket wird JETZT unterdrückt"));
        }
        if (!visible) {
            event.setCancelled(true);
        }
    }

    /**
     * Läuft nur einmal pro Debug-Aktivierung: listet alle öffentlichen,
     * parameterlosen Methoden des tatsächlichen Waypoint-Objekts (und,
     * falls vorhanden, seines Identifier-Unterobjekts) im Server-Log auf.
     * Das zeigt uns schwarz auf weiß, wie die UUID in DEINER installierten
     * PacketEvents-Version wirklich heißt, falls extractPlayerUuid() sie
     * nicht automatisch findet.
     */
    private void logClassInfoOnce(Object waypointObject) {
        if (dumpedClassInfoThisSession || waypointObject == null) {
            return;
        }
        dumpedClassInfoThisSession = true;
        plugin.getLogger().info("[Debug] === Reflection-Dump der Waypoint-Klasse (einmalig) ===");
        dumpMethods("waypoint", waypointObject);
        for (String identifierAccessor : IDENTIFIER_ACCESSOR_NAMES) {
            Method method = findMethod(waypointObject.getClass(), identifierAccessor);
            if (method == null) {
                continue;
            }
            try {
                Object identifier = method.invoke(waypointObject);
                if (identifier != null) {
                    dumpMethods("waypoint." + identifierAccessor + "()", identifier);
                }
            } catch (Exception ex) {
                plugin.getLogger().info("[Debug]   (Aufruf von " + identifierAccessor + "() fehlgeschlagen: " + ex + ")");
            }
        }
        plugin.getLogger().info("[Debug] === Ende Reflection-Dump ===");
    }

    private void dumpMethods(String label, Object object) {
        plugin.getLogger().info("[Debug] " + label + " -> Klasse: " + object.getClass().getName());
        for (Method m : object.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && !m.getDeclaringClass().equals(Object.class)) {
                plugin.getLogger().info("[Debug]   Methode: " + m.getReturnType().getSimpleName() + " " + m.getName() + "()");
            }
        }
    }

    private boolean canSee(UUID viewer, UUID target) {
        if (hideStateManager.isForcedVisible(target)) {
            return true;
        }
        PlayerVisibilitySettings settings = settingsManager.getSettings(target);
        return settings.isVisibleTo(viewer);
    }

    /**
     * Versucht, die UUID des durch das Waypoint repräsentierten Spielers
     * zu ermitteln. Siehe Klassen-Javadoc für den Hintergrund.
     */
    private UUID extractPlayerUuid(Object waypoint) throws Exception {
        if (waypoint == null) {
            return null;
        }

        Object direct = tryExtractUuid(waypoint);
        if (direct != null) {
            return (UUID) direct;
        }

        for (String identifierAccessor : IDENTIFIER_ACCESSOR_NAMES) {
            Method method = findMethod(waypoint.getClass(), identifierAccessor);
            if (method == null) {
                continue;
            }
            Object identifier = method.invoke(waypoint);
            Object fromIdentifier = tryExtractUuid(identifier);
            if (fromIdentifier != null) {
                return (UUID) fromIdentifier;
            }
        }
        return null;
    }

    private Object tryExtractUuid(Object source) throws Exception {
        return tryExtractUuid(source, 0);
    }

    private Object tryExtractUuid(Object source, int depth) throws Exception {
        if (source == null || depth > 3) {
            return null;
        }
        if (source instanceof UUID) {
            return source;
        }
        // java.util.Optional auspacken, falls eine Either-Implementierung
        // left()/right() als Optional<T> zurückgibt.
        if (source instanceof java.util.Optional<?> optional) {
            return optional.isPresent() ? tryExtractUuid(optional.get(), depth + 1) : null;
        }
        for (String name : UUID_ACCESSOR_NAMES) {
            Method method = findMethod(source.getClass(), name);
            if (method == null) {
                continue;
            }
            Object result = method.invoke(source);
            if (result instanceof UUID) {
                return result;
            }
        }
        // Either-Wrapper: die Spieler-UUID steckt oft nicht direkt in der
        // obersten Methode, sondern in einem verschachtelten Either<UUID,
        // String>. Erkennbar am Klassennamen (z.B. com.github.retrooper.
        // packetevents.util.Either oder com.mojang.datafixers.util.Either).
        if (source.getClass().getSimpleName().toLowerCase().contains("either")) {
            for (String name : EITHER_LEFT_ACCESSOR_NAMES) {
                Method method = findMethod(source.getClass(), name);
                if (method == null) {
                    continue;
                }
                try {
                    Object leftValue = method.invoke(source);
                    Object resolved = tryExtractUuid(leftValue, depth + 1);
                    if (resolved != null) {
                        return resolved;
                    }
                } catch (Exception ex) {
                    // Diese Methode war die falsche Seite des Either (z.B.
                    // ein benannter Welt-Wegpunkt statt eines Spielers) oder
                    // nicht anwendbar -> einfach den nächsten Kandidaten probieren.
                }
            }
        }
        return null;
    }

    private Method findMethod(Class<?> clazz, String name) {
        try {
            Method method = clazz.getMethod(name);
            method.setAccessible(true);
            return method;
        } catch (NoSuchMethodException ex) {
            return null;
        }
    }
}
