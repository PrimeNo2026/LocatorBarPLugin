package de.locatorprivacy.waypoints;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWaypoint;
import de.locatorprivacy.hide.HideStateManager;
import de.locatorprivacy.settings.PlayerVisibilitySettings;
import de.locatorprivacy.settings.SettingsManager;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Das eigentliche Herzstück des Plugins.
 *
 * Die vanilla Locator-Bar-Attribute (waypoint_transmit_range /
 * waypoint_receive_range) sind symmetrisch: sie legen nur fest, OB ein
 * Spieler überhaupt als Waypoint gesendet wird, nicht FÜR WEN. Eine
 * individuelle "A sieht B, C aber nicht"-Steuerung ist damit nicht
 * möglich (siehe Machbarkeitsanalyse).
 *
 * Deshalb wird hier jedes ausgehende Waypoint-Paket (PacketType.Play.
 * Server.WAYPOINT, seit 1.21.6) pro Empfänger einzeln abgefangen und bei
 * Bedarf unterdrückt, bevor es den Client erreicht. Dadurch bekommt jeder
 * Spieler nur die Waypoints der Spieler, die ihn laut deren persönlicher
 * Einstellung (oder laut Hide-Zwangssichtbarkeit) sehen lassen.
 *
 * WICHTIGER HINWEIS ZUR WARTUNG:
 * Das Waypoint-System ist eine noch recht junge Minecraft-Funktion
 * (seit 1.21.6) und die PacketEvents-Wrapper-Klassen dafür können sich
 * zwischen PacketEvents-Versionen in Details unterscheiden. Die Methode
 * extractPlayerUuid() versucht deshalb mehrere gängige Methodennamen
 * reflektiv, statt sich auf eine einzige, exakte Signatur zu verlassen.
 * Falls dein Server nach dem Deployment KEINE Paket-Filterung zeigt,
 * prüfe zuerst mit /locatorprivacy debug (siehe README) oder den
 * Server-Log, ob extractPlayerUuid() eine UUID findet, und passe bei
 * Bedarf die Kandidaten-Methodennamen unten an die exakte Javadoc-Version
 * deiner installierten PacketEvents-JAR an.
 */
public class WaypointVisibilityListener extends PacketListenerAbstract {

    private static final String[] IDENTIFIER_ACCESSOR_NAMES = {"getIdentifier", "identifier"};
    private static final String[] UUID_ACCESSOR_NAMES = {"getUuid", "uuid", "getId", "id", "getPlayerId", "playerId"};

    private final JavaPlugin plugin;
    private final SettingsManager settingsManager;
    private final HideStateManager hideStateManager;

    public WaypointVisibilityListener(JavaPlugin plugin, SettingsManager settingsManager, HideStateManager hideStateManager) {
        super(PacketListenerPriority.NORMAL);
        this.plugin = plugin;
        this.settingsManager = settingsManager;
        this.hideStateManager = hideStateManager;
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        if (event.getPacketType() != PacketType.Play.Server.WAYPOINT) {
            return;
        }
        if (!(event.getPlayer() instanceof Player viewer)) {
            return;
        }

        WrapperPlayServerWaypoint wrapper;
        UUID targetUuid;
        try {
            wrapper = new WrapperPlayServerWaypoint(event);
            targetUuid = extractPlayerUuid(wrapper.getWaypoint());
        } catch (Exception ex) {
            // Nicht dekodierbares/unbekanntes Waypoint-Paket (z.B. ein
            // zukünftiges Format) -> sicherheitshalber unverändert durchlassen,
            // statt den Spieler-Client potenziell zu brechen.
            plugin.getLogger().log(Level.FINE, "Konnte Waypoint-Paket nicht lesen, lasse es unverändert durch.", ex);
            return;
        }

        if (targetUuid == null) {
            // Kein spielerbezogenes Waypoint (z.B. ein Welt-Wegpunkt) -> nicht unser Fall.
            return;
        }
        if (targetUuid.equals(viewer.getUniqueId())) {
            return; // jeder sieht sich immer selbst
        }

        if (!canSee(viewer.getUniqueId(), targetUuid)) {
            event.setCancelled(true);
        }
    }

    private boolean canSee(UUID viewer, UUID target) {
        if (hideStateManager.isForcedVisible(target)) {
            return true;
        }
        PlayerVisibilitySettings settings = settingsManager.getSettings(target);
        return settings.isVisibleTo(viewer);
    }

    /**
     * Versucht, die UUID des durch das Waypoint repräsentierten Spielers
     * zu ermitteln. Siehe Klassen-Javadoc für den Hintergrund.
     */
    private UUID extractPlayerUuid(Object waypoint) throws Exception {
        if (waypoint == null) {
            return null;
        }

        Object direct = tryExtractUuid(waypoint);
        if (direct != null) {
            return (UUID) direct;
        }

        for (String identifierAccessor : IDENTIFIER_ACCESSOR_NAMES) {
            Method method = findMethod(waypoint.getClass(), identifierAccessor);
            if (method == null) {
                continue;
            }
            Object identifier = method.invoke(waypoint);
            Object fromIdentifier = tryExtractUuid(identifier);
            if (fromIdentifier != null) {
                return (UUID) fromIdentifier;
            }
        }
        return null;
    }

    private Object tryExtractUuid(Object source) throws Exception {
        if (source == null) {
            return null;
        }
        if (source instanceof UUID) {
            return source;
        }
        for (String name : UUID_ACCESSOR_NAMES) {
            Method method = findMethod(source.getClass(), name);
            if (method == null) {
                continue;
            }
            Object result = method.invoke(source);
            if (result instanceof UUID) {
                return result;
            }
        }
        return null;
    }

    private Method findMethod(Class<?> clazz, String name) {
        try {
            Method method = clazz.getMethod(name);
            method.setAccessible(true);
            return method;
        } catch (NoSuchMethodException ex) {
            return null;
        }
    }
}
