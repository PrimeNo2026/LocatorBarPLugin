package de.locatorprivacy.hide;

import de.locatorprivacy.settings.PlayerVisibilitySettings;
import de.locatorprivacy.settings.SettingsManager;
import de.locatorprivacy.settings.VisibilityMode;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Verwaltet den serverweiten Hide-Modus (ON/OFF) sowie, im OFF-Modus,
 * das 10-Minuten-Versteck-Fenster und die 10-Minuten-Abklingzeit pro Spieler.
 *
 * Alles wird ausschließlich über absolute Zeitstempel (System.currentTimeMillis())
 * gesteuert und nach jeder Änderung sofort auf die Platte geschrieben
 * (hidestate.yml). Dadurch überleben Fenster und Abklingzeit Neustarts
 * und können nicht durch Relogging umgangen werden.
 *
 * Designentscheidung zur Abklingzeit: "Mindestens ein anderer Spieler muss
 * den Spieler sehen können" wird so umgesetzt, dass der Spieler während der
 * Abklingzeit für ALLE Spieler sichtbar ist (statt für genau einen fest
 * gewählten). Das erfüllt die Mindestanforderung zuverlässig, auch wenn
 * einzelne Spieler offline gehen, und ist deutlich weniger fehleranfällig
 * als eine Auswahl "genau eines" Zwangs-Betrachters.
 */
public class HideStateManager {

    private final JavaPlugin plugin;
    private final SettingsManager settingsManager;
    private final File file;

    private ServerHideMode mode;
    private final Map<UUID, PlayerHideState> states = new ConcurrentHashMap<>();

    private final long hideWindowMillis;
    private final long cooldownMillis;

    public HideStateManager(JavaPlugin plugin, SettingsManager settingsManager) {
        this.plugin = plugin;
        this.settingsManager = settingsManager;
        this.file = new File(plugin.getDataFolder(), "hidestate.yml");

        long hideWindowMinutes = plugin.getConfig().getLong("hide-window-minutes", 10);
        long cooldownMinutes = plugin.getConfig().getLong("cooldown-minutes", 10);
        this.hideWindowMillis = hideWindowMinutes * 60_000L;
        this.cooldownMillis = cooldownMinutes * 60_000L;
    }

    public void load() {
        states.clear();
        // WICHTIG: bewusst get() statt getString() verwendet und über
        // parseMode() geleitet. YAML interpretiert unquotierte Werte wie
        // "OFF"/"ON"/"YES"/"NO" automatisch als Boolean (true/false) statt
        // als Text (YAML-1.1-Spezifikation) – getString() würde ein
        // vorhandenes Boolean dann zu "true"/"false" verwandeln, was
        // ServerHideMode.valueOf() zum Absturz bringt. parseMode() fängt
        // genau diesen Fall zusätzlich ab.
        mode = parseMode(plugin.getConfig().get("default-hide-mode"), ServerHideMode.OFF);

        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        mode = parseMode(yaml.get("mode"), mode);
        if (yaml.isConfigurationSection("players")) {
            for (String key : yaml.getConfigurationSection("players").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    long hideWindowEndsAt = yaml.getLong("players." + key + ".hideWindowEndsAt", 0L);
                    long cooldownEndsAt = yaml.getLong("players." + key + ".cooldownEndsAt", 0L);
                    states.put(uuid, new PlayerHideState(hideWindowEndsAt, cooldownEndsAt));
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().log(Level.WARNING, "Ungültiger Spieler-Eintrag in hidestate.yml: " + key, ex);
                }
            }
        }
    }

    /**
     * Wandelt einen rohen Konfigurationswert robust in einen ServerHideMode
     * um. Deckt drei Fälle ab:
     *  - Der Wert ist bereits korrekt als Text da ("ON"/"OFF", beliebige
     *    Groß-/Kleinschreibung).
     *  - YAML hat den Wert (z.B. aus einer unquotierten "OFF"-Zeile) als
     *    Boolean interpretiert -> false wird zu OFF, true zu ON gemappt.
     *  - Der Wert fehlt oder ist unbrauchbar -> fallback wird verwendet,
     *    nie ein Absturz.
     */
    private ServerHideMode parseMode(Object raw, ServerHideMode fallback) {
        if (raw instanceof ServerHideMode m) {
            return m;
        }
        if (raw instanceof Boolean b) {
            return b ? ServerHideMode.ON : ServerHideMode.OFF;
        }
        if (raw != null) {
            try {
                return ServerHideMode.valueOf(raw.toString().trim().toUpperCase());
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().log(Level.WARNING,
                        "Ungültiger Hide-Modus-Wert \"" + raw + "\", nutze Fallback " + fallback + ".", ex);
            }
        }
        return fallback;
    }

    public void save() {
        if (mode == null) {
            // Defensive Absicherung: sollte load() aus irgendeinem Grund
            // nie gelaufen sein, verhindert das hier eine NullPointerException
            // beim Herunterfahren des Plugins.
            mode = ServerHideMode.OFF;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("mode", mode.name());
        for (Map.Entry<UUID, PlayerHideState> entry : states.entrySet()) {
            String key = "players." + entry.getKey();
            yaml.set(key + ".hideWindowEndsAt", entry.getValue().getHideWindowEndsAt());
            yaml.set(key + ".cooldownEndsAt", entry.getValue().getCooldownEndsAt());
        }
        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Konnte hidestate.yml nicht speichern", ex);
        }
    }

    public ServerHideMode getMode() {
        return mode;
    }

    private PlayerHideState getState(UUID player) {
        return states.computeIfAbsent(player, k -> new PlayerHideState());
    }

    /**
     * Wird von /hide on|off aufgerufen. Kümmert sich um den in Abschnitt 3
     * geforderten Übergang: bereits unbegrenzt versteckte Spieler dürfen
     * beim Wechsel ON -> OFF nicht unbegrenzt versteckt bleiben.
     */
    public void setMode(ServerHideMode newMode) {
        ServerHideMode oldMode = this.mode;
        this.mode = newMode;

        if (newMode == ServerHideMode.ON) {
            // Im ON-Modus gibt es keine Fenster/Abklingzeit-Mechanik mehr.
            states.clear();
        } else if (oldMode == ServerHideMode.ON && newMode == ServerHideMode.OFF) {
            long now = System.currentTimeMillis();
            long deadline = now + hideWindowMillis;
            // Jeder Spieler, der aktuell persönlich auf NONE steht, bekommt
            // ab jetzt ein ganz normales 10-Minuten-Fenster, danach Abklingzeit.
            for (PlayerVisibilitySettings settings : settingsManagerAllNoneSettings()) {
                PlayerHideState state = getState(settings.getOwner());
                state.setHideWindowEndsAt(deadline);
                state.setCooldownEndsAt(0L);
            }
        }
        save();
    }

    private Iterable<PlayerVisibilitySettings> settingsManagerAllNoneSettings() {
        return settingsManager.allWithMode(VisibilityMode.NONE);
    }

    /**
     * Wird aufgerufen, wenn ein Spieler seine persönliche Einstellung auf
     * NONE setzt (über das /locator-GUI). Startet ggf. das Hide-Fenster.
     *
     * @return true, wenn die Einstellung übernommen werden darf; false,
     *         wenn der Spieler sich aktuell noch in der Abklingzeit
     *         befindet und deshalb nicht vollständig verstecken darf.
     */
    public boolean tryStartHiding(UUID player) {
        if (mode == ServerHideMode.ON) {
            return true;
        }
        long now = System.currentTimeMillis();
        PlayerHideState state = getState(player);
        if (state.isCooldownActive(now)) {
            return false;
        }
        state.setHideWindowEndsAt(now + hideWindowMillis);
        state.setCooldownEndsAt(0L);
        save();
        return true;
    }

    /**
     * True, wenn der Spieler sich gerade in der erzwungenen Mindest-
     * sichtbarkeit (Abklingzeit) befindet und deshalb unabhängig von
     * seiner persönlichen Einstellung sichtbar sein muss.
     */
    public boolean isForcedVisible(UUID player) {
        if (mode != ServerHideMode.OFF) {
            return false;
        }
        PlayerHideState state = states.get(player);
        if (state == null) {
            return false;
        }
        return state.isCooldownActive(System.currentTimeMillis());
    }

    public long getRemainingCooldownSeconds(UUID player) {
        PlayerHideState state = states.get(player);
        if (state == null) {
            return 0L;
        }
        long remaining = state.getCooldownEndsAt() - System.currentTimeMillis();
        return Math.max(0L, remaining / 1000L);
    }

    /**
     * Periodischer Check (siehe HideCooldownTask): wandelt abgelaufene
     * Hide-Fenster automatisch in eine Abklingzeit um und räumt
     * abgelaufene Abklingzeiten wieder auf.
     */
    public void tick() {
        if (mode != ServerHideMode.OFF) {
            return;
        }
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Map.Entry<UUID, PlayerHideState> entry : states.entrySet()) {
            PlayerHideState state = entry.getValue();

            boolean hideJustExpired = state.getHideWindowEndsAt() != 0L
                    && !state.isHideWindowActive(now)
                    && state.getCooldownEndsAt() == 0L;
            if (hideJustExpired) {
                state.setCooldownEndsAt(state.getHideWindowEndsAt() + cooldownMillis);
                changed = true;
            }

            boolean cooldownJustExpired = state.getCooldownEndsAt() != 0L
                    && !state.isCooldownActive(now)
                    && !state.isHideWindowActive(now);
            if (cooldownJustExpired) {
                state.setHideWindowEndsAt(0L);
                state.setCooldownEndsAt(0L);
                changed = true;
            }
        }
        if (changed) {
            save();
        }
    }
}
