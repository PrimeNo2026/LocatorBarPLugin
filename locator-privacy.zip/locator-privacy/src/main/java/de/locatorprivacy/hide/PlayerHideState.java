package de.locatorprivacy.hide;

/**
 * Zeitstempel-basierter Zustand eines Spielers im OFF-Modus.
 * Es werden ausschließlich absolute Zeitpunkte (epoch millis) gespeichert,
 * NICHT Restzeiten – dadurch ist das System immun gegen Neustarts,
 * Serverzeit-Drift zwischen Ticks und Relogging.
 *
 * hideWindowEndsAt: Zeitpunkt, bis zu dem der Spieler sich (im OFF-Modus)
 *                    vollständig verstecken darf. 0 = kein aktives Fenster.
 * cooldownEndsAt:    Zeitpunkt, bis zu dem die Abklingzeit läuft und
 *                     mindestens ein anderer Spieler ihn sehen MUSS.
 *                     0 = keine aktive Abklingzeit.
 */
public class PlayerHideState {

    private long hideWindowEndsAt;
    private long cooldownEndsAt;

    public PlayerHideState() {
        this(0L, 0L);
    }

    public PlayerHideState(long hideWindowEndsAt, long cooldownEndsAt) {
        this.hideWindowEndsAt = hideWindowEndsAt;
        this.cooldownEndsAt = cooldownEndsAt;
    }

    public long getHideWindowEndsAt() {
        return hideWindowEndsAt;
    }

    public void setHideWindowEndsAt(long hideWindowEndsAt) {
        this.hideWindowEndsAt = hideWindowEndsAt;
    }

    public long getCooldownEndsAt() {
        return cooldownEndsAt;
    }

    public void setCooldownEndsAt(long cooldownEndsAt) {
        this.cooldownEndsAt = cooldownEndsAt;
    }

    public boolean isHideWindowActive(long now) {
        return hideWindowEndsAt > now;
    }

    public boolean isCooldownActive(long now) {
        return cooldownEndsAt > now;
    }
}
