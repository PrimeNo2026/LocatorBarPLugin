package de.locatorprivacy.hide;

public enum ServerHideMode {
    /** Unbegrenztes Verstecken, keine Abklingzeit. */
    ON,
    /** Maximal 10 Minuten Verstecken, danach 10 Minuten Abklingzeit. */
    OFF
}
