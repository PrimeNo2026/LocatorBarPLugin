package de.locatorprivacy.hide;

import org.bukkit.scheduler.BukkitRunnable;

/**
 * Läuft regelmäßig im Hintergrund und sorgt dafür, dass abgelaufene
 * Hide-Fenster automatisch in die Abklingzeit übergehen (siehe
 * HideStateManager#tick()). Die eigentliche Sichtbarkeitsprüfung passiert
 * aber live im WaypointVisibilityListener bei jedem gesendeten Paket –
 * dieser Task dient nur der Zustandspflege und Persistenz.
 */
public class HideCooldownTask extends BukkitRunnable {

    private final HideStateManager hideStateManager;

    public HideCooldownTask(HideStateManager hideStateManager) {
        this.hideStateManager = hideStateManager;
    }

    @Override
    public void run() {
        hideStateManager.tick();
    }
}
