package de.locatorprivacy.settings;

/**
 * Die drei persönlichen Sichtbarkeits-Einstellungen eines Spielers.
 */
public enum VisibilityMode {
    /** Jeder Spieler kann mich auf der Locator Bar sehen. */
    ALL,
    /** Kein Spieler kann mich auf der Locator Bar sehen. */
    NONE,
    /** Nur die Spieler in meiner persönlichen Liste können mich sehen. */
    SELECTED
}
