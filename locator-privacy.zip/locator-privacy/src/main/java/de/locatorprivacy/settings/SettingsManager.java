package de.locatorprivacy.settings;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * Lädt und speichert die persönlichen Sichtbarkeits-Einstellungen
 * aller Spieler UUID-basiert in settings.yml. Überlebt Neustarts.
 */
public class SettingsManager {

    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, PlayerVisibilitySettings> cache = new ConcurrentHashMap<>();

    public SettingsManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "settings.yml");
    }

    public void load() {
        cache.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (String key : yaml.getKeys(false)) {
            try {
                UUID owner = UUID.fromString(key);
                String modeRaw = yaml.getString(key + ".mode", "ALL");
                VisibilityMode mode = VisibilityMode.valueOf(modeRaw);
                Set<UUID> viewers = ConcurrentHashMap.newKeySet();
                yaml.getStringList(key + ".selected").stream()
                        .map(UUID::fromString)
                        .forEach(viewers::add);
                cache.put(owner, new PlayerVisibilitySettings(owner, mode, viewers));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().log(Level.WARNING, "Ungültiger Eintrag in settings.yml: " + key, ex);
            }
        }
    }

    public void saveAll() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (PlayerVisibilitySettings settings : cache.values()) {
            String key = settings.getOwner().toString();
            yaml.set(key + ".mode", settings.getMode().name());
            yaml.set(key + ".selected", settings.getAllowedViewers().stream()
                    .map(UUID::toString)
                    .collect(Collectors.toList()));
        }
        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Konnte settings.yml nicht speichern", ex);
        }
    }

    public PlayerVisibilitySettings getSettings(UUID owner) {
        return cache.computeIfAbsent(owner, PlayerVisibilitySettings::new);
    }

    public void setMode(UUID owner, VisibilityMode mode) {
        getSettings(owner).setMode(mode);
        saveAll();
    }

    public void addViewer(UUID owner, UUID viewer) {
        getSettings(owner).addViewer(viewer);
        saveAll();
    }

    public void removeViewer(UUID owner, UUID viewer) {
        getSettings(owner).removeViewer(viewer);
        saveAll();
    }

    /**
     * Alle bekannten Einstellungen mit einem bestimmten Modus.
     * Wird von HideStateManager beim Wechsel ON -> OFF genutzt.
     */
    public Iterable<PlayerVisibilitySettings> allWithMode(VisibilityMode mode) {
        return cache.values().stream()
                .filter(s -> s.getMode() == mode)
                .collect(Collectors.toList());
    }
}
