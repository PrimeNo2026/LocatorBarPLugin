package de.locatorprivacy.settings;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Persönliche Sichtbarkeits-Einstellung eines einzelnen Spielers.
 * Enthält den gewählten Modus sowie, falls SELECTED aktiv ist,
 * die UUIDs der Spieler, die ihn sehen dürfen.
 */
public class PlayerVisibilitySettings {

    private final UUID owner;
    private VisibilityMode mode;
    private final Set<UUID> allowedViewers;

    public PlayerVisibilitySettings(UUID owner) {
        this(owner, VisibilityMode.ALL, new HashSet<>());
    }

    public PlayerVisibilitySettings(UUID owner, VisibilityMode mode, Set<UUID> allowedViewers) {
        this.owner = owner;
        this.mode = mode;
        this.allowedViewers = allowedViewers;
    }

    public UUID getOwner() {
        return owner;
    }

    public VisibilityMode getMode() {
        return mode;
    }

    public void setMode(VisibilityMode mode) {
        this.mode = mode;
    }

    public Set<UUID> getAllowedViewers() {
        return allowedViewers;
    }

    public void addViewer(UUID viewer) {
        allowedViewers.add(viewer);
    }

    public void removeViewer(UUID viewer) {
        allowedViewers.remove(viewer);
    }

    /**
     * Prüft die REIN persönliche Einstellung (ohne Hide-Zwangssichtbarkeit).
     */
    public boolean isVisibleTo(UUID viewer) {
        if (owner.equals(viewer)) {
            return true;
        }
        return switch (mode) {
            case ALL -> true;
            case NONE -> false;
            case SELECTED -> allowedViewers.contains(viewer);
        };
    }
}
