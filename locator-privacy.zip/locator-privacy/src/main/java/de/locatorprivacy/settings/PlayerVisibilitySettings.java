package de.locatorprivacy.settings;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Persönliche Sichtbarkeits-Einstellung eines einzelnen Spielers.
 * Enthält den gewählten Modus sowie, falls SELECTED aktiv ist,
 * die UUIDs der Spieler, die ihn sehen dürfen.
 *
 * WICHTIG: PacketEvents verarbeitet Pakete standardmäßig NICHT auf dem
 * Haupt-Server-Thread, sondern auf dem Netty-Thread. Da isVisibleTo() aus
 * dem Waypoint-Paket-Listener heraus gelesen wird, während GUI-Klicks und
 * Befehle (Haupt-Thread) gleichzeitig schreiben, muss allowedViewers
 * nebenläufig-sicher sein – ein normales HashSet wäre hier ein Bug
 * (ConcurrentModificationException oder stille Dateninkonsistenz möglich).
 * mode ist aus demselben Grund volatile, damit Schreibzugriffe vom
 * Haupt-Thread sofort für den Paket-Thread sichtbar sind.
 */
public class PlayerVisibilitySettings {

    private final UUID owner;
    private volatile VisibilityMode mode;
    private final Set<UUID> allowedViewers;

    public PlayerVisibilitySettings(UUID owner) {
        this(owner, VisibilityMode.ALL, ConcurrentHashMap.newKeySet());
    }

    public PlayerVisibilitySettings(UUID owner, VisibilityMode mode, Set<UUID> allowedViewers) {
        this.owner = owner;
        this.mode = mode;
        this.allowedViewers = allowedViewers;
    }

    public UUID getOwner() {
        return owner;
    }

    public VisibilityMode getMode() {
        return mode;
    }

    public void setMode(VisibilityMode mode) {
        this.mode = mode;
    }

    public Set<UUID> getAllowedViewers() {
        return allowedViewers;
    }

    public void addViewer(UUID viewer) {
        allowedViewers.add(viewer);
    }

    public void removeViewer(UUID viewer) {
        allowedViewers.remove(viewer);
    }

    /**
     * True, wenn der Spieler aktuell für ALLE anderen Spieler unsichtbar
     * wäre – entweder durch Modus NONE, oder durch Modus SELECTED mit einer
     * (noch) leeren Liste. Beide Fälle sind aus Sicht des Hide-Systems
     * gleichwertig und müssen deshalb identisch über HideStateManager
     * gegated werden, sonst lässt sich die 10-Minuten-Begrenzung über
     * "Ausgewählte Spieler ohne Auswahl" umgehen.
     */
    public boolean isFullyHidden() {
        return mode == VisibilityMode.NONE
                || (mode == VisibilityMode.SELECTED && allowedViewers.isEmpty());
    }

    /**
     * Prüft die REIN persönliche Einstellung (ohne Hide-Zwangssichtbarkeit).
     */
    public boolean isVisibleTo(UUID viewer) {
        if (owner.equals(viewer)) {
            return true;
        }
        return switch (mode) {
            case ALL -> true;
            case NONE -> false;
            case SELECTED -> allowedViewers.contains(viewer);
        };
    }
}
