package de.locatorprivacy.commands;

import de.locatorprivacy.gui.LocatorMenu;
import de.locatorprivacy.settings.PlayerVisibilitySettings;
import de.locatorprivacy.settings.SettingsManager;
import de.locatorprivacy.settings.VisibilityMode;
import de.locatorprivacy.util.Messages;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /locator            -> öffnet das GUI
 * /locator add <name>  -> fügt einen Spieler (auch offline) zur Liste "Ausgewählte Spieler" hinzu
 * /locator remove <name> -> entfernt einen Spieler aus der Liste
 * /locator list        -> zeigt die aktuelle Liste
 *
 * Die add/remove/list-Unterbefehle existieren zusätzlich zum GUI, weil
 * ein Inventar-GUI naturgemäß keine Offline-Spieler auflisten kann.
 */
public class LocatorCommand implements CommandExecutor, TabCompleter {

    private final SettingsManager settingsManager;

    public LocatorCommand(SettingsManager settingsManager) {
        this.settingsManager = settingsManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Messages.ONLY_PLAYERS);
            return true;
        }
        if (!player.hasPermission("locatorprivacy.use")) {
            player.sendMessage(Messages.NO_PERMISSION);
            return true;
        }

        if (args.length == 0) {
            PlayerVisibilitySettings settings = settingsManager.getSettings(player.getUniqueId());
            player.openInventory(LocatorMenu.build(player, settings));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "add" -> handleAdd(player, args);
            case "remove" -> handleRemove(player, args);
            case "list" -> handleList(player);
            default -> player.sendMessage(Messages.error("Nutzung: /locator | /locator add <name> | /locator remove <name> | /locator list"));
        }
        return true;
    }

    private void handleAdd(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(Messages.error("Nutzung: /locator add <name>"));
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(Messages.error("Du musst dich nicht selbst hinzufügen, du siehst dich immer."));
            return;
        }
        settingsManager.addViewer(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(Messages.viewerAdded(target.getName() != null ? target.getName() : args[1]));
    }

    private void handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(Messages.error("Nutzung: /locator remove <name>"));
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        settingsManager.removeViewer(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(Messages.viewerRemoved(target.getName() != null ? target.getName() : args[1]));
    }

    private void handleList(Player player) {
        PlayerVisibilitySettings settings = settingsManager.getSettings(player.getUniqueId());
        player.sendMessage(Messages.info("Modus: " + settings.getMode().name()));
        if (settings.getMode() != VisibilityMode.SELECTED) {
            return;
        }
        if (settings.getAllowedViewers().isEmpty()) {
            player.sendMessage(Messages.info("Deine Liste ist aktuell leer."));
            return;
        }
        String names = settings.getAllowedViewers().stream()
                .map(uuid -> {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
                    return op.getName() != null ? op.getName() : uuid.toString();
                })
                .collect(Collectors.joining(", "));
        player.sendMessage(Component.text("Darf dich sehen: ", NamedTextColor.GRAY).append(Component.text(names, NamedTextColor.AQUA)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String sub : List.of("add", "remove", "list")) {
                if (sub.startsWith(args[0].toLowerCase())) {
                    result.add(sub);
                }
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    result.add(online.getName());
                }
            }
        }
        return result;
    }
}
