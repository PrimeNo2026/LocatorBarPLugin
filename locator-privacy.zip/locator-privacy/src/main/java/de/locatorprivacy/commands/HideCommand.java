package de.locatorprivacy.commands;

import de.locatorprivacy.hide.HideStateManager;
import de.locatorprivacy.hide.ServerHideMode;
import de.locatorprivacy.util.Messages;
import de.locatorprivacy.waypoints.WaypointVisibilityListener;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

/**
 * /hide on      -> unbegrenztes Verstecken erlauben
 * /hide off     -> 10-Minuten-System mit Abklingzeit aktivieren
 * /hide status  -> aktuellen Modus anzeigen
 * /hide debug   -> Diagnose-Logging für die Waypoint-Paket-Filterung umschalten
 *
 * Nur für Spieler mit locatorprivacy.admin.hide (siehe plugin.yml).
 */
public class HideCommand implements CommandExecutor, TabCompleter {

    private final HideStateManager hideStateManager;
    private final WaypointVisibilityListener waypointVisibilityListener;

    public HideCommand(HideStateManager hideStateManager, WaypointVisibilityListener waypointVisibilityListener) {
        this.hideStateManager = hideStateManager;
        this.waypointVisibilityListener = waypointVisibilityListener;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("locatorprivacy.admin.hide")) {
            sender.sendMessage(Messages.NO_PERMISSION);
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage(Messages.UNKNOWN_SUBCOMMAND);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "on" -> {
                hideStateManager.setMode(ServerHideMode.ON);
                sender.sendMessage(Messages.hideModeSet("ON (unbegrenztes Verstecken)"));
            }
            case "off" -> {
                hideStateManager.setMode(ServerHideMode.OFF);
                sender.sendMessage(Messages.hideModeSet("OFF (10 Minuten Verstecken, 10 Minuten Abklingzeit)"));
            }
            case "status" -> {
                String modeText = hideStateManager.getMode() == ServerHideMode.ON
                        ? "ON (unbegrenztes Verstecken)"
                        : "OFF (10 Minuten Verstecken, 10 Minuten Abklingzeit)";
                sender.sendMessage(Messages.hideStatus(modeText));
                sender.sendMessage(Messages.info("Debug-Logging: " + (waypointVisibilityListener.isDebug() ? "AN" : "AUS")));
            }
            case "debug" -> {
                boolean newState = !waypointVisibilityListener.isDebug();
                waypointVisibilityListener.setDebug(newState);
                sender.sendMessage(Messages.success("Waypoint-Debug-Logging ist jetzt " + (newState ? "AN" : "AUS")
                        + ". " + (newState
                        ? "Schau in die Server-Konsole, während zwei Spieler online sind und sich bewegen."
                        : "")));
            }
            default -> sender.sendMessage(Messages.UNKNOWN_SUBCOMMAND);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String sub : List.of("on", "off", "status", "debug")) {
                if (sub.startsWith(args[0].toLowerCase())) {
                    result.add(sub);
                }
            }
        }
        return result;
    }
}
