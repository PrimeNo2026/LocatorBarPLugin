package de.locatorprivacy;

import com.github.retrooper.packetevents.PacketEvents;
import de.locatorprivacy.commands.HideCommand;
import de.locatorprivacy.commands.LocatorCommand;
import de.locatorprivacy.gui.MenuListener;
import de.locatorprivacy.hide.HideCooldownTask;
import de.locatorprivacy.hide.HideStateManager;
import de.locatorprivacy.settings.SettingsManager;
import de.locatorprivacy.waypoints.WaypointVisibilityListener;
import org.bukkit.plugin.java.JavaPlugin;

public class LocatorPrivacyPlugin extends JavaPlugin {

    private SettingsManager settingsManager;
    private HideStateManager hideStateManager;
    private WaypointVisibilityListener waypointVisibilityListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        settingsManager = new SettingsManager(this);
        settingsManager.load();

        hideStateManager = new HideStateManager(this, settingsManager);
        hideStateManager.load();

        // Befehle registrieren
        LocatorCommand locatorCommand = new LocatorCommand(settingsManager);
        getCommand("locator").setExecutor(locatorCommand);
        getCommand("locator").setTabCompleter(locatorCommand);

        HideCommand hideCommand = new HideCommand(hideStateManager);
        getCommand("hide").setExecutor(hideCommand);
        getCommand("hide").setTabCompleter(hideCommand);

        // GUI-Listener
        getServer().getPluginManager().registerEvents(
                new MenuListener(settingsManager, hideStateManager), this);

        // Paket-Listener für die individuelle Waypoint-Sichtbarkeit.
        // Setzt voraus, dass das PacketEvents-Plugin bereits aktiv ist
        // (siehe depend: [packetevents] in plugin.yml).
        waypointVisibilityListener = new WaypointVisibilityListener(this, settingsManager, hideStateManager);
        PacketEvents.getAPI().getEventManager().registerListener(waypointVisibilityListener);

        // Hintergrund-Task: Hide-Fenster -> Abklingzeit Übergänge
        long intervalTicks = getConfig().getLong("check-interval-ticks", 20);
        new HideCooldownTask(hideStateManager).runTaskTimer(this, intervalTicks, intervalTicks);

        getLogger().info("LocatorPrivacy wurde aktiviert. Hide-Modus: " + hideStateManager.getMode());
    }

    @Override
    public void onDisable() {
        if (settingsManager != null) {
            settingsManager.saveAll();
        }
        if (hideStateManager != null) {
            hideStateManager.save();
        }
        // Kein manuelles unregisterListener nötig: PacketEvents entfernt
        // Listener seines Hosts automatisch, wenn das Plugin deaktiviert wird.
        // Falls deine PacketEvents-Version das nicht tut, kannst du hier
        // PacketEvents.getAPI().getEventManager().unregisterListener(waypointVisibilityListener)
        // ergänzen.
    }

    public SettingsManager getSettingsManager() {
        return settingsManager;
    }

    public HideStateManager getHideStateManager() {
        return hideStateManager;
    }
}
