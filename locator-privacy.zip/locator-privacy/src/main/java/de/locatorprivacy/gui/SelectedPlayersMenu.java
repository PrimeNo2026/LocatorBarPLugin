package de.locatorprivacy.gui;

import de.locatorprivacy.settings.PlayerVisibilitySettings;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

/**
 * Untermenü zu "Ausgewählte Spieler": zeigt alle aktuell ONLINE Spieler
 * (außer sich selbst) als Spielerköpfe, grün = darf mich sehen,
 * grau = darf mich (noch) nicht sehen. Klick togglet.
 *
 * Offline-Spieler können zusätzlich über /locator add <name> bzw.
 * /locator remove <name> verwaltet werden (siehe LocatorCommand) –
 * ein reines Inventar-GUI kann naturgemäß keine Offline-Spieler auflisten.
 */
public final class SelectedPlayersMenu {

    public static final int SLOT_BACK = 49;

    private SelectedPlayersMenu() {
    }

    public static Inventory build(Player viewer, PlayerVisibilitySettings settings) {
        SelectedPlayersMenuHolder holder = new SelectedPlayersMenuHolder();
        Inventory inventory = Bukkit.createInventory(holder, 54,
                Component.text("Ausgewählte Spieler", NamedTextColor.DARK_AQUA));
        holder.setInventory(inventory);

        int slot = 0;
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.getUniqueId().equals(viewer.getUniqueId())) {
                continue;
            }
            if (slot >= 45) {
                break; // Grenze erreicht, restliche Reihe bleibt für Steuer-Items frei
            }
            boolean allowed = settings.getAllowedViewers().contains(online.getUniqueId());
            inventory.setItem(slot, buildHead(online, allowed));
            slot++;
        }

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.displayName(Component.text("Zurück", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
        back.setItemMeta(backMeta);
        inventory.setItem(SLOT_BACK, back);

        return inventory;
    }

    private static ItemStack buildHead(Player target, boolean allowed) {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(target);
        NamedTextColor color = allowed ? NamedTextColor.GREEN : NamedTextColor.GRAY;
        meta.displayName(Component.text(target.getName(), color).decoration(TextDecoration.ITALIC, false));

        Component status = allowed
                ? Component.text("✔ Darf dich sehen – klicken zum Entfernen", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false)
                : Component.text("Darf dich nicht sehen – klicken zum Hinzufügen", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
        meta.lore(List.of(status));

        item.setItemMeta(meta);
        return item;
    }
}
