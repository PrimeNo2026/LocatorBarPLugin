package de.locatorprivacy.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/**
 * Markiert ein Inventar als das Untermenü zur Verwaltung einzelner
 * Betrachter (Ausgewählte Spieler hinzufügen/entfernen).
 */
public class SelectedPlayersMenuHolder implements InventoryHolder {

    private Inventory inventory;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
