package de.locatorprivacy.gui;

import de.locatorprivacy.settings.PlayerVisibilitySettings;
import de.locatorprivacy.settings.VisibilityMode;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Baut das Haupt-GUI für /locator: Alle / Niemand / Ausgewählte Spieler.
 */
public final class LocatorMenu {

    public static final int SLOT_ALL = 11;
    public static final int SLOT_NONE = 13;
    public static final int SLOT_SELECTED = 15;

    private LocatorMenu() {
    }

    public static Inventory build(Player player, PlayerVisibilitySettings settings) {
        MainMenuHolder holder = new MainMenuHolder();
        Inventory inventory = org.bukkit.Bukkit.createInventory(holder, 27,
                Component.text("Locator-Bar Sichtbarkeit", NamedTextColor.DARK_AQUA));
        holder.setInventory(inventory);

        inventory.setItem(SLOT_ALL, buildOption(
                Material.LIME_DYE,
                "Alle",
                "Jeder Spieler kann dich auf der Locator Bar sehen.",
                settings.getMode() == VisibilityMode.ALL));

        inventory.setItem(SLOT_NONE, buildOption(
                Material.RED_DYE,
                "Niemand",
                "Kein Spieler kann dich auf der Locator Bar sehen.",
                settings.getMode() == VisibilityMode.NONE));

        inventory.setItem(SLOT_SELECTED, buildOption(
                Material.PLAYER_HEAD,
                "Ausgewählte Spieler",
                "Nur Spieler aus deiner Liste können dich sehen. Klicken zum Verwalten.",
                settings.getMode() == VisibilityMode.SELECTED));

        return inventory;
    }

    private static ItemStack buildOption(Material material, String name, String description, boolean active) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        NamedTextColor color = active ? NamedTextColor.GREEN : NamedTextColor.WHITE;
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));

        Component statusLine = active
                ? Component.text("✔ Aktiv", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false)
                : Component.text("Klicken zum Aktivieren", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);

        meta.lore(List.of(
                Component.text(description, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                statusLine
        ));
        if (active) {
            meta.setEnchantmentGlintOverride(true);
        }
        item.setItemMeta(meta);
        return item;
    }
}
