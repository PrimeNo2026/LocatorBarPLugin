package de.locatorprivacy.gui;

import de.locatorprivacy.hide.HideStateManager;
import de.locatorprivacy.settings.PlayerVisibilitySettings;
import de.locatorprivacy.settings.SettingsManager;
import de.locatorprivacy.settings.VisibilityMode;
import de.locatorprivacy.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class MenuListener implements Listener {

    private final SettingsManager settingsManager;
    private final HideStateManager hideStateManager;

    public MenuListener(SettingsManager settingsManager, HideStateManager hideStateManager) {
        this.settingsManager = settingsManager;
        this.hideStateManager = hideStateManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof MainMenuHolder) {
            event.setCancelled(true);
            handleMainMenuClick(event);
        } else if (event.getInventory().getHolder() instanceof SelectedPlayersMenuHolder) {
            event.setCancelled(true);
            handleSelectedPlayersClick(event);
        }
    }

    private void handleMainMenuClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        // Klicks außerhalb des oberen Inventars (z.B. eigenes Inventar) ignorieren
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        int slot = event.getSlot();
        PlayerVisibilitySettings settings = settingsManager.getSettings(player.getUniqueId());

        if (slot == LocatorMenu.SLOT_ALL) {
            settingsManager.setMode(player.getUniqueId(), VisibilityMode.ALL);
            player.sendMessage(Messages.visibilitySet("Alle"));
            refreshMainMenu(player);
        } else if (slot == LocatorMenu.SLOT_NONE) {
            boolean allowed = hideStateManager.tryStartHiding(player.getUniqueId());
            if (!allowed) {
                long remaining = hideStateManager.getRemainingCooldownSeconds(player.getUniqueId());
                player.sendMessage(Messages.cannotHideYet(remaining));
                return;
            }
            settingsManager.setMode(player.getUniqueId(), VisibilityMode.NONE);
            player.sendMessage(Messages.visibilitySet("Niemand"));
            refreshMainMenu(player);
        } else if (slot == LocatorMenu.SLOT_SELECTED) {
            settingsManager.setMode(player.getUniqueId(), VisibilityMode.SELECTED);
            player.sendMessage(Messages.visibilitySet("Ausgewählte Spieler"));
            player.openInventory(SelectedPlayersMenu.build(player, settings));
        }
    }

    private void handleSelectedPlayersClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        int slot = event.getSlot();
        if (slot == SelectedPlayersMenu.SLOT_BACK) {
            refreshMainMenu(player);
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() != Material.PLAYER_HEAD) {
            return;
        }
        if (!(clicked.getItemMeta() instanceof SkullMeta skullMeta) || skullMeta.getOwningPlayer() == null) {
            return;
        }
        OfflinePlayer target = skullMeta.getOwningPlayer();
        PlayerVisibilitySettings settings = settingsManager.getSettings(player.getUniqueId());

        if (settings.getAllowedViewers().contains(target.getUniqueId())) {
            settingsManager.removeViewer(player.getUniqueId(), target.getUniqueId());
            player.sendMessage(Messages.viewerRemoved(target.getName() != null ? target.getName() : target.getUniqueId().toString()));
        } else {
            settingsManager.addViewer(player.getUniqueId(), target.getUniqueId());
            player.sendMessage(Messages.viewerAdded(target.getName() != null ? target.getName() : target.getUniqueId().toString()));
        }
        // Submenü neu aufbauen, damit die Farbe sofort aktualisiert wird
        player.openInventory(SelectedPlayersMenu.build(player, settingsManager.getSettings(player.getUniqueId())));
    }

    private void refreshMainMenu(Player player) {
        PlayerVisibilitySettings settings = settingsManager.getSettings(player.getUniqueId());
        player.openInventory(LocatorMenu.build(player, settings));
    }
}
