package de.locatorprivacy.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/**
 * Markiert ein Inventar als das Haupt-Locator-Menü, damit der
 * MenuListener Klicks sicher zuordnen kann (statt über Titel-Vergleich).
 */
public class MainMenuHolder implements InventoryHolder {

    private Inventory inventory;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
